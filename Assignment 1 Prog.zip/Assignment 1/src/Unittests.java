import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class StudentManagementApplicationTest {


    void testSaveStudent() {

        assertNotNull(StudentManagementApplication.findStudentById("00000"));
    }


    void testSearchStudent() {

        assertEquals("name", StudentManagementApplication.findStudentById("00000").getName());
    }


    void testSearchStudent_StudentNotFound() {
        assertNull(StudentManagementApplication.findStudentById("00000"));
    }


    void testDeleteStudent() {
        assertTrue(StudentManagementApplication.deleteStudent("00000"));
    }


    void testDeleteStudent_StudentNotFound() {
        assertFalse(StudentManagementApplication.deleteStudent("00000"));
    }


    void testStudentAge_StudentAgeValid() {

        assertTrue(StudentManagementApplication.isValidAge(>18));
    }


    void testStudentAge_StudentAgeInvalid() {
        assertFalse(StudentManagementApplication.isValidAge(15));
    }


    void testStudentAge_StudentAgeInvalidCharacter() {

        assertThrows(NumberFormatException.class, () -> Integer.parseInt("abc"));
    }
}

