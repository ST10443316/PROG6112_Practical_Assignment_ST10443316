// A to do list to help people manage their time and remember things which are very important
class Task {
    // task description and completion status down here
    private String description;
    private boolean isCompleted;

    // Constructor to initialize the task with a description;
    public Task(String description) {
        this.description = description;
        this.isCompleted = false;
    }

    // Method to mark the task as completed
    public void complete() {
        this.isCompleted = true;
    }

    // Getter method to retrieve the task description
    public String getDescription() {
        return description;
    }

    // Getter method to check if the task is completed
    public boolean isCompleted() {
        return isCompleted;
    }
}

// Class for managing the list of tasks
class ToDoList {
    // an Array to store tasks and a counter to track the number of tasks added.:)
    private Task[] tasks;
    private int taskCount;

    // Constructor to initialize the to-do list with a fixed size
    public ToDoList(int size) {
        tasks = new Task[size];  // an array to hold tasks
        taskCount = 0;
    }


    public void addTask(String description) {//adding tasks
        if (taskCount < tasks.length) {
            tasks[taskCount++] = new Task(description);
            //Add task if there's space and if the tasks are full a message is required
        } else {
            System.out.println("Task list is full.");
        }
    }

    //a method to mark a task as completed as a default
    public void completeTask(int index) {
        //a method to mark the task as complete if the index is valid with an else reponse
        if (index >= 0 && index < taskCount) {
            tasks[index].complete();

        } else {
            System.out.println("Invalid task index.");
        }
    }

    //completion status of tasks
    public void displayTasks() {
        System.out.println("To-Do List:");
        for (int i = 0; i < taskCount; i++) {
            System.out.println((i + 1) + ". " + tasks[i].getDescription() +
                    " (Completed: " + tasks[i].isCompleted() + ")");
        }
    }
}

//main class
public class Main {
    public static void main(String[] args) {
        // Create a to-do list with space for 10 tasks
        ToDoList myList = new ToDoList(10);

        // Add tasks to the to-do list
        myList.addTask(" ICE task 1");
        myList.addTask("Finish homework");
        myList.addTask("PROG assignment");

        // Mark the second task ("Finish homework") as completed
        myList.completeTask(1);

        // Display the entire to-do list along with the status of each task
        myList.displayTasks();
    }
}//inspired by general OOP principles url: https://www.geeksforgeeks.org/inheritance-in-java/


