import java.util.ArrayList;
import java.util.Scanner;

// Student class definition to store student details
class Student {
    private String studentId; // Unique ID for each student
    private String name;      // Name of the student
    private int age;          // Age of the student
    private String email;     // Email of the student
    private String course;    // Course the student is enrolled in

    // Constructor to initialize a Student object
    public Student(String studentId, String name, int age, String email, String course) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters for accessing private fields
    public String getStudentId() {
        return studentId;
    }
//here


    // Overriding toString method to print student details
    @Override
    public String toString() {
        return "Student ID: " + studentId + "\n" +
                "STUDENT NAME: " + name + "\n" +
                "STUDENT AGE: " + age + "\n" +
                "STUDENT EMAIL: " + email + "\n" +
                "STUDENT COURSE: " + course;
    }
}

// Main method
public class StudentManagementApplication {
    // the memory so it can save students names after i capture them
    private static ArrayList<Student> students = new ArrayList<>();
    //a 2D array could work
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("STUDENT MANAGEMENT APPLICATION");
            System.out.println("********************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            String choice = scanner.nextLine();
            //if the user does not press 1 i should prompt the application to exit whic is an if statement

            if (!choice.equals("1")) {
                break;
            }

            // the second menu should show up after user clicks 1
            displayMenu(scanner);
        }


        scanner.close();
    }

    // Method to display the menu and handle user choices
    private static void displayMenu(Scanner scanner) {
        while (true) {
            System.out.println("Please select one of the following menu items:");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application.");
            String choice = scanner.nextLine();

            // Switch-case to handle different menu options
            switch (choice) {
                case "1":
                    captureStudent(scanner); // Capture a new student
                    break;
                case "2":
                    searchStudent(scanner); // Search for a student by ID
                    break;
                case "3":
                    deleteStudent(scanner); // Delete a student by ID
                    break;
                case "4":
                    printStudentReport(); // Print the report of all students
                    break;
                case "5":
                    return; // Exit the menu
               // default:
                   // System.out.println("Invalid choice. Please try again."); // for  invalid input
            }
        }
    }

    // Method to capture a new student
    private static void captureStudent(Scanner scanner) {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("******************************");

        // to imput student id
        System.out.print("Enter the student id: ");
        String studentId = scanner.nextLine();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;//age must be older than 16 years/only numbers are allowes
        while (true) {
            try {
                System.out.print("Enter the student age: ");
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) { // Validate age, must be 16 or older
                    break;
                } else {
                    System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please re-enter the student age >>");
            }
        }//adapted from programmiz, url : programiz.com/java-programming/do-while-loop

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        // a student option to enter to inform the user that everything is crrect
        Student student = new Student(studentId, name, age, email, course);
        students.add(student);
        System.out.println("Student details have been successfully saved!");
    }

    // Method to search for a student by ID
    private static void searchStudent(Scanner scanner) {
        System.out.print("Enter the student id to search: ");
        String studentId = scanner.nextLine();

        // Find the student by ID
        Student student = findStudentById(studentId);
        if (student != null) {
            System.out.println(student); // display the student's details
        } else {
            System.out.println("Student with Student Id: " + studentId + " was not found!");
        }
    }

    // this one is straight foward enter a name to delete
    private static void deleteStudent(Scanner scanner) {
        System.out.print("Enter the student id to delete: ");
        String studentId = scanner.nextLine();


        Student student = findStudentById(studentId);
        if (student != null) {
            System.out.print("Are you sure you want to delete student " + studentId + " from the system? Yes (y) to delete. ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("y")) {
                students.remove(student); // Remove the student from the list
                System.out.println("Student with Student Id: " + studentId + " WAS deleted!");
            }
        } else {
            System.out.println("Student with Student Id: " + studentId + " was not found!");
        }
    }

    // Method to print a report of all students
    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
            return;
        }
        // for ......students display
        for (int i = 0; i < students.size(); i++) {
            System.out.println("STUDENT " + (i + 1));
            System.out.println(students.get(i));
            System.out.println("-----------------------------------");
        }//addapted from geeksforgeeks, Multidimensional Array in Java, 23 september 2023, Url : https://www.geeksforgeeks.org/multidimensional-arrays-in-java/
    }

    // a static Students to find students by id
    private static Student findStudentById(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                return student; // it must return the studed if its found
            }
        }
        return null; // Return null if student is not found
    }
}//additional requirements
